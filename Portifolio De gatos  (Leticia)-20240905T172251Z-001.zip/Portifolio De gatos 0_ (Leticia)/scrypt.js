const cats = [
    {
        name: "Persa",
        image: "persa.jfif", // Caminho para a imagem local
        page: "persa.html"
    },
    {
        name: "Siamês",
        image: "https://example.com/siames.jpg",
        page: "siames.html"
    },
    {
        name: "Maine Coon",
        image: "https://example.com/mainecoon.jpg",
        page: "mainecoon.html"
    },
    // Adicione mais gatos até completar os 25
];

function displayCats(catArray) {
    const catList = document.getElementById('cat-list');
    catList.innerHTML = ''; // Limpa a lista antes de mostrar os gatos
    catArray.forEach(cat => {
        const catCard = document.createElement('div');
        catCard.className = 'cat-card';
        catCard.onclick = () => {
            window.location.href = cat.page;
        };

        catCard.innerHTML = `
            <img src="${cat.image}" alt="${cat.name}">
            <h2>${cat.name}</h2>
        `;
        catList.appendChild(catCard);
    });
}

// Mostra todos os gatos ao carregar a página
displayCats(cats);
